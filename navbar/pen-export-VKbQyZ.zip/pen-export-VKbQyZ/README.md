# Navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/themustafaomar/pen/VKbQyZ](https://codepen.io/themustafaomar/pen/VKbQyZ).

Lightweight pure Javascript navbar